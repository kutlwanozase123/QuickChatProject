package quickchatproject;

import java.util.Scanner;
import java.util.Random;

public class QuickChatProject {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        // Requirement 1: Login (Placeholder)
        boolean loggedIn = true; 
        if (!loggedIn) {
            System.out.println("You must log in successfully to use this application.");
            return;
        }

        // Requirement 2: Welcome message
        System.out.println("Welcome to QuickChat.");

        // Requirement 5: Define how many messages to send
        System.out.print("How many messages do you wish to enter? ");
        int maxMessages = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        
        int messagesSent = 0; 
        boolean running = true;

        // Requirement 4: Application runs until user selects 'quit'
        while (running) {
            
            // Requirement 3: Numeric Menu
            System.out.println("\n--- Main Menu ---");
            System.out.println("Option 1) Send Messages");
            System.out.println("Option 2) Show recently sent messages");
            System.out.println("Option 3) Quit");
            System.out.print("Please choose an option (1-3): ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    if (messagesSent < maxMessages) {
                        System.out.println("\n--- New Message ---");
                        
                        // REQUIREMENT 6: Generate Unique 10-digit Message ID
                        long messageId = 1000000000L + (long)(random.nextDouble() * 9000000000L);

                        // REQUIREMENT 6: Recipient Input & Validation
                        System.out.print("Enter recipient cell number (max 10 chars, must include intl code like +): ");
                        String recipient = scanner.nextLine();

                        if (recipient.length() > 10 || !recipient.startsWith("+")) {
                            System.out.println("Error: Recipient must contain an international code (e.g., +) and be 10 characters or less.");
                            break; 
                        }

                        // REQUIREMENT 6: Message Input & Validation
                        System.out.print("Enter message (max 250 characters): ");
                        String messageBody = scanner.nextLine();

                        if (messageBody.length() > 250) {
                            System.out.println("Please enter a message of less than 250 characters.");
                        } else {
                            System.out.println("Message sent");
                            messagesSent++; 
                            
                            // REQUIREMENT 6: Message Hash
                            String hash = recipient.substring(0, 2) + ":" + messageBody.substring(0, 2).toUpperCase() + ":" + messageId;
                            
                            System.out.println("---------------------------------");
                            System.out.println("Message ID: " + messageId);
                            System.out.println("Message Hash: " + hash);
                            System.out.println("(" + messagesSent + " out of " + maxMessages + " messages sent)");
                            System.out.println("---------------------------------");
                        }

                    } else {
                        System.out.println("\nYou have reached your limit of " + maxMessages + " messages.");
                        System.out.println("You cannot send any more messages.");
                    }
                    break;

                case 2:
                    System.out.println("\nComing Soon.");
                    break;

                case 3:
                    System.out.println("\nExiting QuickChat. Goodbye!");
                    running = false; 
                    break;

                default:
                    System.out.println("\nInvalid option. Please enter 1, 2, or 3.");
            }
        }

        scanner.close();
    }
}